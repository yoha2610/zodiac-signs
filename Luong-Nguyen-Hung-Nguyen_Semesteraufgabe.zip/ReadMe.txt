Teammitglieder : 

•	Luong Nguyen Hung Nguyen, 20238583
•	Yohanny Carolina Camacaro Querales, 20233384

Beschreibung:
Unsere Website bietet den Nutzern die Möglichkeit, ihr Sternzeichen durch Eingabe ihres Geburtstags zu erfahren. Ihr Sternzeichen wird zusammen mit ihrem Namen und ihrem Geschlecht, das ebenfalls von den Nutzern eingegeben wird, auf einer anderen Website angezeigt.

Parameters:
•	Name des Benutzers: 
•	Der Geburtstag des Benutzers:
•	Das Geschlecht des Benutzers:

URL: http://pan.th-brandenburg.de/~nguyenl/horoscope.html
